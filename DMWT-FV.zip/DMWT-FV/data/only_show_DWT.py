import os
import numpy as np
import pywt
import cv2
import matplotlib.pyplot as plt

# Step 1: 加载图像并预处理
img_path = 'frame01.jpg'  # 替换为你的图像路径
img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
img = cv2.resize(img, (128, 128))
img = img / 255.0  # 归一化

# Step 2: 滑动窗口设置
win_size = 16
stride = 8
H, W = img.shape
patches = []
positions = []

for y in range(0, H - win_size + 1, stride):
    for x in range(0, W - win_size + 1, stride):
        patch = img[y:y+win_size, x:x+win_size]
        patches.append(patch)
        positions.append((x, y))

# Step 3: 二级小波变换 + 能量计算
def compute_wavelet_energy(patch):
    coeffs2 = pywt.wavedec2(patch, 'haar', level=2)
    LL2, (LH2, HL2, HH2), (LH1, HL1, HH1) = coeffs2
    energy = {
        'LL': np.sum(LL2 ** 2),
        'LH': np.sum(LH2 ** 2),
        'HL': np.sum(HL2 ** 2),
        'HH': np.sum(HH2 ** 2)
    }
    return energy

energy_maps = {'LL': [], 'LH': [], 'HL': [], 'HH': []}

for patch in patches:
    energy = compute_wavelet_energy(patch)
    for k in energy:
        energy_maps[k].append(energy[k])

# Step 4: 可视化
n_x = (W - win_size) // stride + 1
n_y = (H - win_size) // stride + 1

for band in ['LL', 'LH', 'HL', 'HH']:
    energy_map = np.array(energy_maps[band]).reshape(n_y, n_x)
    plt.figure(figsize=(5, 4))
    plt.imshow(energy_map, cmap='hot', interpolation='nearest')
    plt.title(f'Wavelet Energy Map - {band} band')
    plt.colorbar()
    plt.tight_layout()
    plt.show()

# 可选：原图与滑窗位置可视化
img_vis = cv2.cvtColor((img * 255).astype(np.uint8), cv2.COLOR_GRAY2BGR)
for (x, y) in positions:
    cv2.rectangle(img_vis, (x, y), (x + win_size, y + win_size), (0, 255, 0), 1)

plt.figure(figsize=(6, 6))
plt.imshow(img_vis[..., ::-1])  # BGR to RGB
plt.title("Sliding Windows on Image")
plt.axis('off')
plt.show()


feature_matrix = np.stack([energy_maps[k] for k in ['LL', 'LH', 'HL', 'HH']], axis=1)
print("Feature shape per frame:", feature_matrix.shape)  # 应为 [n_patches, 4]