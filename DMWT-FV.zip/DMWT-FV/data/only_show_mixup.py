
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import LabelEncoder
import warnings

# 忽略警告
warnings.filterwarnings('ignore')

# ---------------- Step 1: 加载原始数据 ----------------
# 注意：请修改为你的实际路径
df = pd.read_excel('all_wave_dataset_reduced100.xlsx')  # 原始特征数据
X = df.iloc[:, 1:].values  # 特征值部分
y = df.iloc[:, 0].values   # 标签部分（0/1）

# 标签转换为整数编码
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

# ---------------- Step 2: 应用 Mixup 插值 ----------------
def mixup_data(X, y, alpha=0.2):
    """在特征空间中进行Mixup插值"""
    batch_size = X.shape[0]
    indices = np.random.permutation(batch_size)
    lam = np.random.beta(alpha, alpha)

    mixed_X = lam * X + (1 - lam) * X[indices]
    mixed_y = lam * y + (1 - lam) * y[indices]
    return mixed_X, mixed_y

X_mix, y_mix = mixup_data(X, y_encoded, alpha=0.2)

# ---------------- Step 3: 合并原始与Mixup样本 ----------------
X_combined = np.vstack([X, X_mix])
y_combined = np.hstack([y_encoded, y_mix])
labels = np.array(['Original'] * len(X) + ['Mixup'] * len(X_mix))  # 区分来源

# ---------------- Step 4: PCA降维至3D空间 ----------------
pca = PCA(n_components=3)
X_pca = pca.fit_transform(X_combined)

# ---------------- Step 5: 绘制3D可视化 ----------------
from mpl_toolkits.mplot3d import Axes3D
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# 原始样本
ax.scatter(
    X_pca[labels == 'Original', 0],
    X_pca[labels == 'Original', 1],
    X_pca[labels == 'Original', 2],
    c='blue', label='Original', alpha=0.5
)

# Mixup插值样本
ax.scatter(
    X_pca[labels == 'Mixup', 0],
    X_pca[labels == 'Mixup', 1],
    X_pca[labels == 'Mixup', 2],
    c='orange', label='Mixup', alpha=0.5
)

ax.set_title("3D PCA Visualization of Original and Mixup Features")
ax.set_xlabel("PCA-1")
ax.set_ylabel("PCA-2")
ax.set_zlabel("PCA-3")
ax.legend()
plt.tight_layout()
plt.show()
