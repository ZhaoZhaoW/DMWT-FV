import numpy as np
import pandas as pd
import torch.fft
import warnings
from sklearn.preprocessing import LabelEncoder

import logging
logging.basicConfig(filename='mixup_log.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')


def mixup_data(X, y, alpha=0.3):
    '''应用Mixup到特征和标签'''
    batch_size = X.shape[0]
    indices = np.random.permutation(batch_size)  # 随机排列索引
    lam = np.random.beta(alpha, alpha)  # 生成一个随机的lambda值

    mixed_X = lam * X + (1 - lam) * X[indices]  # 混合特征
    mixed_y = (lam * y + (1 - lam) * y[indices]).round().astype(int)  # 取整并转换为整数类型

    return mixed_X, mixed_y

# 消除警告
warnings.filterwarnings('ignore')

# 读取Excel文件
df = pd.read_excel(r"E:\deep studying\Wavelet&CFormer(DWFormer-WaveNet）\data\all_wave_dataset_reduced100.xlsx") # original_features 为原来（6千=3+1+1+1）条数据；wavelet_all
X = df.iloc[:, 1:].values  # 特征数据
y = df.iloc[:, 0].values    # 标签数据


# 将标签转换为整数（如果标签是类别型字符串）
label_encoder = LabelEncoder()
y = label_encoder.fit_transform(y)  # 转换为整数标签

# 应用 Mixup 数据增强  X_train: 训练特征，y_train: 训练标签
X_train, y_train = mixup_data(X, y, alpha=0.2)

# 将增强数据转化为DataFrame或其他格式，方便后续处理
augmented_df = pd.DataFrame(X_train)
# augmented_df['label'] = y_train
augmented_df.insert(0, 'label', y_train.astype(int))  # 在第一列插入标签
#保存Mixup 结果
augmented_df.to_excel('mix_data_new.xlsx', index=False)

# 将原始数据转化为DataFrame
original_df = pd.DataFrame(X)
original_df.insert(0, 'label', y)  # 插入标签列

# 合并原始数据和增强数据
combined_df = pd.concat([original_df, augmented_df], ignore_index=True)

# 将合并的数据保存为新的Excel文件
combined_df.to_excel('mix_data_new.xlsx', index=False)


