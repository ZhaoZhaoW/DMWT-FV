import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from mpl_toolkits.mplot3d import Axes3D

# ------------------------ 参数配置 ------------------------
img1_path = 'sample1.jpg'  # 原始图像路径1   (sample1)薄手套攻击；(sample2) 厚手套攻击
img2_path = 'sample2.jpg'  # 原始图像路径2
patch_size = 16
stride = 8
alpha = 0.2
wavelet = 'db1'

# ------------------------ 图像级Mixup ------------------------
def mixup_images(img1, img2, lam):
    return cv2.addWeighted(img1, lam, img2, 1 - lam, 0)

img1 = cv2.imread(img1_path, cv2.IMREAD_GRAYSCALE)
img2 = cv2.imread(img2_path, cv2.IMREAD_GRAYSCALE)
img1 = cv2.resize(img1, (39, 110))
img2 = cv2.resize(img2, (39, 110))
lam = np.random.beta(alpha, alpha)
img_mix = mixup_images(img1, img2, lam)

# ------------------------ 小波特征提取 ------------------------
import pywt

def extract_wave_energy(image):
    h, w = image.shape
    features = []
    for y in range(0, h - patch_size + 1, stride):
        for x in range(0, w - patch_size + 1, stride):
            patch = image[y:y + patch_size, x:x + patch_size]
            coeffs2 = pywt.dwt2(patch, wavelet)
            LL, (LH, HL, HH) = coeffs2
            energy = [
                np.sum(LL ** 2),
                np.sum(LH ** 2),
                np.sum(HL ** 2),
                np.sum(HH ** 2)
            ]
            features.append(energy)
    return np.array(features)

feat1 = extract_wave_energy(img1)
feat2 = extract_wave_energy(img2)
feat_mix = lam * feat1 + (1 - lam) * feat2  # 特征级Mixup

# ------------------------ PCA降维可视化 ------------------------
all_feats = np.stack([feat1.flatten(), feat2.flatten(), feat_mix.flatten()], axis=0)
pca = PCA(n_components=3)
feats_pca = pca.fit_transform(all_feats)

fig = plt.figure(figsize=(12, 5))

# -------- 子图1：图像空间Mixup对比 --------
plt.subplot(1, 2, 1)
plt.title("Image-Level Mixup Comparison")
plt.imshow(np.hstack([img1, img2, img_mix]), cmap='gray')
plt.axis('off')
plt.xlabel("Original 1       +       Original 2       +       Mixup")
plt.text(0.5, -0.05, "Original 1                         Original 2                         Mixup",
         fontsize=10, ha='center', va='top', transform=plt.gca().transAxes)




# -------- 子图2：特征空间分布 --------
ax = fig.add_subplot(1, 2, 2, projection='3d')
ax.scatter(*feats_pca[0], c='blue', label='Feature 1', s=60)
ax.scatter(*feats_pca[1], c='green', label='Feature 2', s=60)
ax.scatter(*feats_pca[2], c='red', label='Mixup Feature', s=60, marker='^')
ax.set_title("Feature-Space Distribution (PCA-3D)")
ax.set_xlabel("PC1")
ax.set_ylabel("PC2")
ax.set_zlabel("PC3")
ax.legend()

plt.tight_layout()
plt.show()
