# import numpy as np
# import matplotlib.pyplot as plt
# from sklearn.decomposition import PCA
# from mpl_toolkits.mplot3d import Axes3D
# import seaborn as sns
# import pandas as pd
#
# # 设置可视化模式：True = 3D，False = 2D
# IS_3D = False
#
# # ---------------------- Step 1: 加载数据 ------------------------
# # （推荐方式）从 .npz 加载原始特征
# npz_file = 'wave_video_dataset100.npz'
# data = np.load(npz_file, allow_pickle=True)
# features = data['features']  # [N, T, 4]
# labels = data['labels']      # [N]
#
# print(f"[INFO] Loaded features shape: {features.shape}, labels shape: {labels.shape}")
#
# # 展平为 [N, T×4]，准备 PCA 降维
# N, T, C = features.shape
# X = features.reshape(N, T * C)
# y = labels
#
# # ---------------------- Step 2: PCA 降维 ------------------------
# pca = PCA(n_components=3 if IS_3D else 2)
# X_pca = pca.fit_transform(X)
#
# print(f"[INFO] Explained variance ratio: {pca.explained_variance_ratio_}")
# print(f"[INFO] Reduced shape: {X_pca.shape}")
#
# # ---------------------- Step 3: 绘图 ------------------------
# plt.figure(figsize=(8, 6))
# palette = sns.color_palette("hls", len(np.unique(y)))
#
# if IS_3D:
#     ax = plt.subplot(111, projection='3d')
#     for class_id in np.unique(y):
#         idx = y == class_id
#         ax.scatter(X_pca[idx, 0], X_pca[idx, 1], X_pca[idx, 2],
#                    label=f"{'Real' if class_id==0 else 'Fake'}",
#                    s=50, alpha=0.75, c=[palette[class_id]])
#     ax.set_xlabel('PCA-1')
#     ax.set_ylabel('PCA-2')
#     ax.set_zlabel('PCA-3')
# else:
#     for class_id in np.unique(y):
#         idx = y == class_id
#         plt.scatter(X_pca[idx, 0], X_pca[idx, 1],
#                     label=f"{'Real' if class_id==0 else 'Fake'}",
#                     s=50, alpha=0.75, c=[palette[class_id]])
#     plt.xlabel('PCA-1')
#     plt.ylabel('PCA-2')
#
# plt.title("PCA Projection of Vein Features")
# plt.legend()
# plt.grid(True)
# plt.tight_layout()
# plt.show()




#   3D 可视化效果
import numpy as np
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401 for 3D plotting
import seaborn as sns

# -----------------------------
# 1. 加载预处理好的数据文件
# -----------------------------
data = np.load('wave_video_dataset100.npz', allow_pickle=True)
features = data['features']  # [N, T, 4]
labels = data['labels']      # [N]

# -----------------------------
# 2. 展平特征为 [N, T×4]
# -----------------------------
N, T, C = features.shape     # C=4
X = features.reshape(N, T * C)

# -----------------------------
# 3. PCA降维到3维
# -----------------------------
pca = PCA(n_components=3)
X_reduced = pca.fit_transform(X)

print(f"[INFO] PCA explained variance ratios: {pca.explained_variance_ratio_}")
print(f"[INFO] Shape after PCA: {X_reduced.shape}")

# -----------------------------
# 4. 绘制3D可视化散点图
# -----------------------------
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# 设置颜色映射（0为真实，1为伪造）
palette = sns.color_palette("husl", 2)
colors = [palette[int(l)] for l in labels]

ax.scatter(X_reduced[:, 0], X_reduced[:, 1], X_reduced[:, 2],
           c=colors, marker='o', edgecolors='k', alpha=0.7)

ax.set_xlabel('PCA Component 1')
ax.set_ylabel('PCA Component 2')
ax.set_zlabel('PCA Component 3')
ax.set_title('3D PCA Scatter Plot of Wavelet Video Features')

legend_labels = ['Real', 'Fake']
for i, label_name in enumerate(legend_labels):
    ax.scatter([], [], [], c=palette[i], label=label_name)
ax.legend()

plt.tight_layout()
plt.show()
