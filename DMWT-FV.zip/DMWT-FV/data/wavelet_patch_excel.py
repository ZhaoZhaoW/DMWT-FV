import numpy as np
from sklearn.decomposition import PCA
import pandas as pd

# 加载 .npz 数据
data = np.load('wave_video_dataset100.npz', allow_pickle=True)
features = data['features']  # [N, T, 4]
labels = data['labels']      # [N]

# 展开为 [N, T*4]
N, T, C = features.shape
X = features.reshape(N, T * C)

# 主成分分析：将高维特征压缩为 D 维
pca = PCA(n_components=50)  # 可设为 50 或使用 cumulative explained variance 判断
X_reduced = pca.fit_transform(X)  # [N, 50]

# 合并标签
df = pd.DataFrame(X_reduced)
df['label'] = labels

# 保存为 Excel 表格
df.to_excel("wave_dataset_reduced100.xlsx", index=False)
print("[INFO] Saved to wave_dataset_reduced100.xlsx")
