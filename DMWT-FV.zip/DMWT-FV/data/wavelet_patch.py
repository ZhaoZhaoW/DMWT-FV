import os
import numpy as np
import pywt
import cv2
from tqdm import tqdm

def extract_wave_energy_sequence(image, patch_size=16, stride=8, wavelet='db1'):
    h, w = image.shape
    features = []
    for y in range(0, h - patch_size + 1, stride):
        for x in range(0, w - patch_size + 1, stride):
            patch = image[y:y + patch_size, x:x + patch_size]
            coeffs2 = pywt.dwt2(patch, wavelet)
            LL, (LH, HL, HH) = coeffs2
            energy = [
                np.sum(LL ** 2),
                np.sum(LH ** 2),
                np.sum(HL ** 2),
                np.sum(HH ** 2)
            ]
            features.append(energy)
    return np.array(features)  # shape: [T, 4]

def process_video(video_path, patch_size=16, stride=8, wavelet='db1'):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"[WARN] Failed to open: {video_path}")
        return None

    video_sequence = []
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        feat = extract_wave_energy_sequence(gray, patch_size, stride, wavelet)
        video_sequence.append(feat)

    cap.release()

    if not video_sequence:
        return None

    return np.concatenate(video_sequence, axis=0)  # shape: [T_total, 4]

def collect_all_video_features(root_dir, label, patch_size=16, stride=8):
    features = []
    labels = []
    video_count = 0

    for subdir1 in os.listdir(root_dir):
        subdir1_path = os.path.join(root_dir, subdir1)
        if not os.path.isdir(subdir1_path):
            continue

        for subdir2 in os.listdir(subdir1_path):
            subdir2_path = os.path.join(subdir1_path, subdir2)
            if not os.path.isdir(subdir2_path):
                continue

            for fname in os.listdir(subdir2_path):
                if fname.endswith(('.mp4', '.avi')):
                    path = os.path.join(subdir2_path, fname)
                    print(f"[INFO] Processing video: {path}")
                    feat = process_video(path, patch_size, stride)
                    if feat is not None:
                        features.append(feat)
                        labels.append(label)
                        video_count += 1

    print(f"[INFO] Total videos processed from {root_dir}: {video_count}")
    return features, labels

def pad_sequences(seq_list, max_len=None):
    if max_len is None:
        max_len = max(len(seq) for seq in seq_list)
    padded = np.zeros((len(seq_list), max_len, 4), dtype=np.float32)
    for i, seq in enumerate(seq_list):
        length = len(seq)
        padded[i, :length, :] = seq
    return padded

if __name__ == '__main__':
    real_root = r'E:\deep studying\指静脉\数据库新\true'   # 替换为真实视频根目录
    fake_root = r'E:\deep studying\指静脉\数据库新\false'  # 替换为伪造视频根目录

    real_features, real_labels = collect_all_video_features(real_root, label=0)
    fake_features, fake_labels = collect_all_video_features(fake_root, label=1)

    all_features = real_features + fake_features
    all_labels = real_labels + fake_labels

    features_padded = pad_sequences(all_features)
    labels_array = np.array(all_labels, dtype=np.int64)

    print(f"[INFO] Final dataset shape: {features_padded.shape}, labels: {labels_array.shape}")
    np.savez_compressed('wave_video_dataset100.npz', features=features_padded, labels=labels_array)
    print("[INFO] Dataset saved to wave_video_dataset.npz")
